import "./../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import { Route, Routes } from "react-router-dom";
import UserList from "./Components/UserList";
import Userdetails from "./Components/Userdetails";
import Createuserform from "./Components/Createuserform";
import Header from "./Components/Header";
import EditModal from "./Components/EditModal";

function App() {
  return (
    <>
      <div className="App">
        <header>
          <Header />
        </header>
        <Routes>
          <Route path="/" element={<UserList />} />
          <Route path="/userdetails/:id" element={<Userdetails />} />
          <Route path="/edituser" element={<EditModal />} />
          <Route path="/createuserform" element={<Createuserform />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
