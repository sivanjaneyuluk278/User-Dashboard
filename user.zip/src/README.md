What is the use of this Repo:
This Project is a Simple ReactJS Project which demonstrates the following

1. Creating a Component in React
2. Communicating between parent and child component
3. Using Bootstrap along with React
4. Using Basic Routing in React
5. Using redux state management.

Prerequisites:

Install Node JS
Refer to https://nodejs.org/en/ to install nodejs

1. Install create-react-app
   Install create-react-app npm package globally. This will help to easily run the project and also build the source files easily. Use the following command to install create-react-app

npx create-react-app project-name

Install all the npm packages. Go into the project folder and type the following command to install all npm packages

npm install

In order to run the application Type the following command

npm start

The Application Runs on localhost:3000

Application design:

2. Components

a. UserList Component : This Component displays a list of users. This Component gets the data from a json file db.json (db.json file imported in store.js)

b. userDetails Component : This Component Displays the details of the selected cuser. This Component gets its data from a json file . This Component is the Child Component of UserList Component

c. EditModal Component: This Component Displays the edit details of the selected user.
This Component is the Child Component of UserDetails Component

d. Createuserform Component: This Component Displays new user form to add new user in userList component.

3. Resources:

ReactJS : Refer to https://reactjs.org/ to understand the concepts of ReactJS

React Bootstrap :
Refers to https://getbootstrap.com/docs/5.3/getting-started/introduction/ understand how to use Bootstrap in React

Refer to https://react-bootstrap.netlify.app/docs/components/modal to understand how to create EditMadal Component using React-bootstrap

4. Using Basic Routing in React:

Refer to https://www.npmjs.com/package/react-router-dom to understand how to perform navigation.

install the react router dom

npm i react-router-dom

5. Using redux state management:

Refer to https://redux-toolkit.js.org/introduction/getting-started to understand how use state management in React Application

Install redux packages

npm install @reduxjs/toolkit

npm install react-redux

or npm install @reduxjs/toolkit react-redux
