import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router";
import { deleteUsers, fetchUsers, selectedUserdetails } from "./Store";

const UserList = () => {
  let tabledata = useSelector((state) => state.user.users);
  let status = useSelector((state) => state.user.status);
  let error = useSelector((state) => state.user.error);
  const [currentPage, setCurrentPage] = useState(1);
  const recordsPerpage = 5;
  const lastIndex = currentPage * recordsPerpage;
  const firstIndex = lastIndex - recordsPerpage;
  const records = tabledata.slice(firstIndex, lastIndex);
  const npage = Math.ceil(tabledata.length / recordsPerpage);
  const numbers = [...Array(npage + 1).keys()].slice(1);

  const deleteUser = (id) => {
    dispatch(deleteUsers(id));
  };

  function prePage() {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1);
    }
  }
  function nextPage() {
    if (currentPage !== npage) {
      setCurrentPage(currentPage + 1);
    }
  }
  function changeCPage(id) {
    setCurrentPage(id);
  }

  const dispatch = useDispatch();
  useEffect(() => {
    if (tabledata.length === 0) {
      dispatch(fetchUsers());
    }
  }, []);

  const navigate = useNavigate();

  const onUserSelect = (item) => {
    dispatch(selectedUserdetails(item));
    navigate(`/userdetails/${item.id}`);
  };
  return (
    <>
      <section className="container">
        <table className="table table-striped">
          <thead>
            <th>Id</th>
            <th>User Name</th>
            <th>Email Id</th>
            <th>Role</th>
          </thead>
          <tbody>
            {records.map((item) => {
              return (
                <tr key={item.id}>
                  <td>{item.id}</td>
                  <td>
                    <button
                      className="selectedUser"
                      onClick={() => onUserSelect(item)}
                    >
                      {item.username}
                    </button>
                  </td>
                  <td>{item.email}</td>
                  <td>{item.role}</td>

                  <td className="d-flex align-items-center gap-4">
                    <button
                      className="btn btn-danger"
                      onClick={() => deleteUser(item.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <nav>
          <ul className="pagination">
            <li className="page-item">
              <a href="#" className="page-link" onClick={prePage}>
                Prev
              </a>
            </li>
            {numbers.map((n, i) => (
              <li
                className={`page-item ${currentPage === n ? "active" : ""}`}
                key={i}
              >
                <a
                  href="#"
                  className="page-link"
                  onClick={() => changeCPage(n)}
                >
                  {n}
                </a>
              </li>
            ))}
            <li className="page-item">
              <a href="#" className="page-link" onClick={nextPage}>
                Next
              </a>
            </li>
          </ul>
        </nav>
      </section>
    </>
  );
};

export default UserList;
