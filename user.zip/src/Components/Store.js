import {
  configureStore,
  createAsyncThunk,
  createSlice,
} from "@reduxjs/toolkit";
import data from "../db.json";

let initialData = {
  users: [],
  selectedUser: {},
  status: "",
  error: false,
};

export let fetchUsers = createAsyncThunk("user/fetch", () => {
  try {
    return data.userData;
  } catch (error) {
    throw error;
  }
});

const userSlice = createSlice({
  name: "user",
  initialState: initialData,

  reducers: {
    fetchUsers: (state, action) => {},
    deleteUsers: (state, action) => {
      const itemId = action.payload;
      state.users = state.users.filter((item) => item.id !== itemId);
    },
    editUsers: (state, action) => {
      const index = state.users.findIndex((item) => {
        return item.id === action.payload.id;
      });
      state.users.splice(index, 1, action.payload);
    },
    selectedUserdetails: (state, action) => {
      state.selectedUser = action.payload;
    },
    createUser: (state, action) => {
      state.users.push(action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUsers.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.status = "completed";
        state.users = action.payload;
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.status = "error";
        state.error = action.error.message;
      });
  },
});

const store = configureStore({
  reducer: {
    user: userSlice.reducer,
  },
});
export const { deleteUsers, selectedUserdetails, editUsers, createUser } =
  userSlice.actions;
export default store;
