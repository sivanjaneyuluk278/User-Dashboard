import React from "react";
import { useNavigate } from "react-router";

const Header = () => {
  const navigate = useNavigate();
  const handleAdduser = () => {
    navigate("/createuserform");
  };
  const homeButton = () => {
    navigate("/");
  };
  return (
    <>
      <header>
        <div className="w-100 mt-3 d-flex align-items-center justify-content-center">
          <h5 className=" m-3 text-primary ">User Dashboard</h5>
          <button
            className="btn btn-primary adduser m-5 "
            onClick={() => handleAdduser()}
          >
            Add User
          </button>
          <button
            className="btn btn-primary home_button "
            onClick={() => homeButton()}
          >
            Home
          </button>
        </div>
      </header>
    </>
  );
};

export default Header;
