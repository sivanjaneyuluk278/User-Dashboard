import React from "react";
import { useSelector, useDispatch } from "react-redux";

import { editUsers } from "./Store";
import Example from "./EditModal";

const Userdetails = () => {
  const [show, setShow] = React.useState(false);
  let selectedUser = useSelector((state) => state.user.selectedUser);

  const { id, name, username, email, role, phone, website } = selectedUser;

  const dispatch = useDispatch();

  const editUser = (item) => {
    dispatch(editUsers(item));
    setShow(true);
  };

  return (
    <>
      <nav className="container m-auto">
        <div className=" w-75 d-flex justify-content-end ">
          <button
            className="btn btn-primary edit_user_button"
            onClick={() => editUser(id)}
          >
            Edit
          </button>
        </div>
        {/* <div className="w-75 d-flex justify-content-start">
          
        </div>
        <div className="w-75 d-flex justify-content-end">
         
        </div> */}
      </nav>
      <section>
        <div className="container">
          <div className="row">
            <div className="col-6">
              <ul className="user_details1">
                <li>
                  <span>Name:</span> {name}
                </li>
                <li>
                  <span>User Name:</span> {username}
                </li>
                <li>
                  <span>Email:</span> {email}
                </li>
                <li>
                  <span>Role:</span> {role}
                </li>
              </ul>
            </div>
            <div className="col-6">
              <ul className="user_details1">
                <li>
                  <span>Phone:</span>
                  {phone}
                </li>
                <li>
                  <span>Website:</span>
                  {website}
                </li>
              </ul>
            </div>
          </div>
        </div>
        <Example selectedUser={selectedUser} show={show} setShow={setShow} />
      </section>
    </>
  );
};

export default Userdetails;
