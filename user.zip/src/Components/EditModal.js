import { useRef } from "react";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import { editUsers, selectedUserdetails } from "./Store";
import { useDispatch } from "react-redux";

function EditModal({ show, setShow, selectedUser }) {
  const handleClose = () => setShow(false);
  const emailRef = useRef(null);
  const usernameRef = useRef(null);
  const roleRef = useRef(null);
  const { email, name, role } = selectedUser;
  const dispatch = useDispatch();
  const onHandleSubmit = () => {
    const obj = {
      ...selectedUser,
      name: usernameRef.current.value,
      email: emailRef.current.value,
      role: roleRef.current.value,
    };

    dispatch(editUsers(obj));
    dispatch(selectedUserdetails(obj));
    handleClose();
  };
  return (
    <>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>User Name</Form.Label>
              <Form.Control
                type="text"
                // placeholder="kondalu"
                ref={usernameRef}
                defaultValue={name}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                // placeholder="name@example.com"
                ref={emailRef}
                defaultValue={email}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="text"
                // placeholder="manager"
                ref={roleRef}
                defaultValue={role}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={onHandleSubmit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default EditModal;
