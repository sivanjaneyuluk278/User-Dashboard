import React, { useState } from "react";
import { useNavigate } from "react-router";
import { useDispatch } from "react-redux";
import { createUser } from "./Store";

function Createuserform() {
  const [formData, setFormData] = useState({
    id: "",
    username: "",
    email: "",
    role: "",
  });
  // const id = useId();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    const uniqueId = Math.random().toString(16).slice(-4);
    const updatedFormData = {
      ...formData,
      id: uniqueId,
    };
    e.preventDefault();
    dispatch(createUser(updatedFormData));
    navigate("/");
  };
  return (
    <>
      <div className="container w-50">
        <h5 className="text-center mb-3">New User </h5>
        <form className=" justify-content-center " onSubmit={handleSubmit}>
          <div class="mb-2">
            <label className="form-label">Name </label>

            <input
              value={formData.name}
              name="name"
              required
              onChange={(e) => handleChange(e)}
              class="form-control"
            />
          </div>
          <div class="mb-2">
            <label className="form-label">User Name </label>

            <input
              value={formData.username}
              name="username"
              required
              onChange={(e) => handleChange(e)}
              class="form-control"
            />
          </div>
          <div class="mb-2">
            <label className="form-label">Email </label>
            <input
              value={formData.email}
              name="email"
              onChange={(e) => handleChange(e)}
              required
              class="form-control"
            />
          </div>
          <div class="mb-2">
            <label className="form-label">Role </label>

            <input
              value={formData.role}
              name="role"
              onChange={(e) => handleChange(e)}
              required
              class="form-control"
            />
          </div>
          <button type="submit" class="btn btn-primary">
            Submit
          </button>
        </form>
      </div>
    </>
  );
}

export default Createuserform;
